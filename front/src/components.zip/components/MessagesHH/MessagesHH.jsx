import { useEffect, useState } from "react"
import { apiHH } from "../../api/api"

const incomeRange = (incomeFrom, incomeTo) => {
   let incomeText = '';

   if (incomeFrom && incomeTo) {
      incomeText = `${incomeFrom}Р - ${incomeTo}Р`;
   } else if (incomeFrom) {
      incomeText = `От ${incomeFrom}Р`;
   } else if (incomeTo) {
      incomeText = `До ${incomeTo}Р`;
   } else {
      incomeText = 'Не указано';
   }
   return incomeText
}

export default function MessagesHH() {
   const [messages, setMessages] = useState([])
   const [selectPerson, setSelectPerson] = useState(null)
   const [selectPdf, setSelectPdf] = useState(undefined)

   useEffect(() => {
      const getMessages = async () => {
         const newMessages = await apiHH.getMessages()
         setMessages(newMessages)
         const newButtons = messages.actions
         buttons(newButtons)
      }

      getMessages()
   }, [])

   const selectedOnId = async (item) => {
      setSelectPerson(item)
      /*
      const res = await apiHH.getPdf(urlPdf)
      setSelectPdf(res.data)
      */
   }

   return (
      <div className="flex">
         <div className="w-1/3">
            {messages.map((item, index) => (
               <div className="flex justify-between gap-x-6 py-5 pr-2 
            hover:bg-gray-100 cursor-pointer"
               onClick={() => selectedOnId(item)}
               key={index}
               >
                  <div className="flex min-w-0 gap-x-4 ml-3">
                     <img className="h-12 w-12 flex-none rounded-full bg-gray-50" src={item.resume?.photo?.small} alt="" />
                     <div className="min-w-0 flex-auto">
                        <p className="text-sm font-semibold leading-6 text-gray-900">{item.resume?.last_name + ' ' + item.resume?.first_name}</p>
                     </div>
                  </div>
                  <div className="hidden shrink-0 sm:flex sm:flex-col sm:items-end">
                     <p className="text-sm leading-6 text-gray-900">{item.vacancy?.name}</p>
                     <p className="mt-1 text-xs leading-5 text-gray-500">{incomeRange(item.vacancy?.salary.from, item.vacancy?.salary.to)}</p>
                  </div>
               </div>
            ))}
         </div>
         <div className="w-2/3 flex flex-col px-20  gap-5">
            {selectPerson && (
               <div className="flex flex-col gap-5">
                  <span className="font-semibold">{selectPerson?.resume.last_name + ' ' + selectPerson?.resume.first_name}</span>
                  <span className="font-semibold">{selectPerson?.resume.title}</span>
                  {selectPerson?.resume.age && <span>{selectPerson?.resume.age} лет</span>}
                  <div className="flex flex-col gap-2"><span className="font-semibold">Образование:</span> {
                     selectPerson?.resume.education.primary.map(item => (
                        <span key={item.name}>{item?.name} - {item?.result} {item?.year}г.</span>)
                     )
                  }
                  </div>
                  <div className="flex flex-col gap-2"><span className="font-semibold">Опыт работы:</span> {selectPerson?.resume?.experience?.map(item => (
                     <span key={item?.company}>{item?.company} {item?.position} {item?.start} - {item?.end ? item?.end : 'н.в'}</span>
                  ))}</div>
                  <span></span>
               </div>
            )}
            {selectPerson && selectPerson.actions.map(item => (
               <button
                  onClick={() => apiHH.command(item.url)}
                  key={item.id}
                  className=" px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600 focus:outline-none"
               >
                  {item?.name}
               </button>
            ))}
         </div>
      </div>
   )
}
// {selectPdf && <PdfViewer pdfData={selectPdf} />}