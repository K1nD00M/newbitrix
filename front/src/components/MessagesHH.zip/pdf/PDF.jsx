import { SpecialZoomLevel, Viewer } from '@react-pdf-viewer/core';
import '@react-pdf-viewer/core/lib/styles/index.css';


const PdfViewer = ({ pdfData, plugins }) => {
   return (
      <Viewer 
         fileUrl={pdfData} 
         defaultScale={SpecialZoomLevel.ActualSize} 
         plugins={plugins}
      />
   );
};

export default PdfViewer;